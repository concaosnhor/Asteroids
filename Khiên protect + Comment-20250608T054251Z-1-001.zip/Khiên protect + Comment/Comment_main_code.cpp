//Class Animation : quản lí animation, định nghĩa và triển khai phương thức hoạt động (số khung hình , tốc độ lồng các khung hình tạo hành động )
class Animation {
    public :
    float Frame , speed;//Số khung hình và tốc độ chuyển đổi giữa các khung hình tạo hoạt ảnh
    std::::vector<InRect> frames ;
}
// Class Enity : Lớp Base cho việc khai báo các object tương tác trong trò chơi( người chơi, thiên thạch, mạng chơi, đạn và va chạm nổ)
class Enity {
    public :
    float x,y,dx,dy,R,angle;
    bool life;
    std::string name;
    //Triển khai hàm ảo (sử dụng tính đa hình Polyphism)
    virtual ~Entity(){}; // Hàm huỷ ảo
}
//Class asteroid : Kế thừa Class Enity -> Thiên thạch trong game
class asteroid : public Enity {
    public :
    asteroid()
    {
        dx=rand()%8-4; // Vận tốc ngang 
        dy=rand()%8-4; // Vận tốc dọc 
        name="asteroid";//Gán cho phát hiện va chạm
}
}
//Class bullet : kế thừa từ Class Enity -> phát hiện va chạm và xử lý
class bullet: public Entity
{
public:
    bullet()
    {
        name="bullet"; // Định danh cho việc phát hiện va chạm
    }
}
//Class player : kế thừa từ Class Enity -> Đại diện người chơi là phi cơ chiến đấu()
class player: public Entity
{
public:
    bool thrust; // Cho biết người chơi có đang tăng tốc hay không ( Sử dụng biến boolean trả về True Flase)

    player()
    {
        name="player"; // Định danh cho việc phát hiện va chạm
    }
}
// Phần này để trống sẽ bổ sung thêm những phần muốn cho thêm vào (mạng chơi, khiên bảo vệ, Menu điều khiển trò chơi,)
// Hàm main điều khiển toàn bộ chương trình. Diễn ra các quá trình khởi tạo game, xử lí hành vi, logic cập nhật và xuất hình ảnh
//1. Khởi tạo game : Quá trình thiết lập cửa sổ game (đóng bật cửa sổ), định nghĩa các object Animation tương ứng bên trên 
//****** QUÁ TRÌNH 2 VÀ 3 TIẾP TỤC BỔ SUNG VÀ CẬP NHẬT ******
//2. Xử lí hành vi : Xử lý các hành vi đầu vào của người dùng (ví dụ: đóng cửa sổ, nhấn phím Space để bắn)
//3. Logic cập nhật : Tiếp nhận xử lí cập nhật quá trình phím mũi tên để điều khiển và thực hiện combo
//3.1 Cập nhật và xử lí va chạm : Va chạm giữa đạn và thiên thạch ( cả 2 cùng phải biến mất), Va chạm giữa phi cơ và thiên thạch (lồng anim vụ nổ ), Va chạm giữa tấm khiên và thiên thạch (biến mất cả 2)
//3.2 Cập nhật trạng thái Class thực thể Enity : tăng tốc, vụ nổ (mất mạng), số thiên thạch là ngẫu nhiên.
//*****Các texture sử dụng cho loạt ảnh animation(tiếp tục cập nhật)*****
t1.loadFromFile("images/spaceship.png");
t2.loadFromFile("images/background.jpg");
t3.loadFromFile("images/explosions/type_C.png");
t4.loadFromFile("images/rock.png");
t5.loadFromFile("images/fire_blue.png");
t6.loadFromFile("images/rock_small.png");
t7.loadFromFile("images/explosions/type_B.png");
t8.loandFromFile
t9.loadFromFile
t10.loadFromFile
